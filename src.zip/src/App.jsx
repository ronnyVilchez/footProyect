import { useEffect, useState } from 'react'
import './App.css'
import { Meals } from './components/Meals'

function App() {
  const [data, setData] = useState("")
  const [meal, setMeal] = useState("")

  const getData = async () => {
    const rs = await fetch('https://www.themealdb.com/api/json/v1/1/filter.php?c=Seafood')
    const jsonRs = await rs.json()
    setData(jsonRs.meals)
    setMeal(jsonRs.meals)
  }
  
  useEffect(() => {
    getData()
  }, [])
  console.log(getData);
  return (
    <>
      <Meals data={data} setData={setData} meal={meal} setMeal={setMeal}/>
    </>
  )
}

export default App