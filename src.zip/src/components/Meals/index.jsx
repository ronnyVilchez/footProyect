import React, { useEffect, useState } from "react";
import './Meals.css'

export const Meals = ({ data, meal, setMeal }) => {
    const [value, setValue] = useState("");

    useEffect(() => {
        if (Array.isArray(data)) {
            const rs = data.filter(m => m.strMeal.toLowerCase().includes(value.toLowerCase()));
            setMeal(rs);
        }
    }, [value, data, setMeal]);

    return (
        <>
            <div className="searching">
                <input onChange={(e) => setValue(e.target.value)} type="text" placeholder="¿Qué quieres ordenar?" className="input" />
                <button className="button">search</button>
            </div>
            <div className="container">
                {meal && meal.map(info => (
                    <div key={info.idMeal} className="container-int">
                        <img src={info.strMealThumb} alt="img de la meal" />
                        <div className="container-int1">
                            <h2><strong>{info.strMeal}</strong></h2>
                            <p><strong>Id Meal:</strong>{info.idMeal}</p>
                        </div>
                    </div>
                ))}
            </div>
        </>
    );
};